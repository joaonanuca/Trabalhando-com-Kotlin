package br.com.aplicativocomcheckbox

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        lateinit var texto : TextView
        lateinit var botao : Button
        lateinit var checkBox : CheckBox

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        texto = findViewById(R.id.textView)
        texto.text = "Desmarcado"
        botao = findViewById(R.id.button)
        checkBox = findViewById(R.id.checkBox)

        checkBox.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener {
            override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean) {
                if(checkBox.isChecked){
                    texto.text = "Marcado"
                }else{
                    texto.text = "Desmarcado"
                }
            }
        })

        botao.setOnClickListener{
            lateinit var isMarcado : String

            if(checkBox.isChecked){
                isMarcado = "Marcado"
            }else{
                isMarcado = "Desmarcado"
            }

            Toast.makeText(applicationContext, "" + isMarcado, Toast.LENGTH_SHORT).show()
        }
    }
}