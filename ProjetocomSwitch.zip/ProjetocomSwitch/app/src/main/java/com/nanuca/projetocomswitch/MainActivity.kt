package com.nanuca.projetocomswitch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var texto: TextView
    lateinit var botao: Button
    lateinit var interruptor: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        texto = findViewById(R.id.statusSwitch)
        botao = findViewById(R.id.button)
        interruptor = findViewById(R.id.switch1)

        interruptor.setOnCheckedChangeListener {
            buttonView, isChecked -> isChecked

            var ligadoDesligado = ""

            if(isChecked){
                ligadoDesligado = "Ligado"
            }else{
                ligadoDesligado = "Desligado"
            }
            texto.text = ligadoDesligado
        }

        botao.setOnClickListener{
            var ligadoDesligado = ""

            if(interruptor.isChecked){
                ligadoDesligado = "Ligado"
            }else{
                ligadoDesligado = "Desligado"
            }

            Toast.makeText(this, ligadoDesligado, Toast.LENGTH_LONG).show()
        }

    }
}